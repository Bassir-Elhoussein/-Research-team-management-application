* DO NOT REMOVE ANY INFORMATION WITHOUT AUTHOR'S PERMISSION

If you find these icons useful we’d like you to pass them on to other who you think might appreciate the set. The URL to share is: http://www.woothemes.com/2009/09/woofunction/

Important: Even though we won’t force you, we appreciate if you link to the above article when sharing the icons.


This icon set is released on the GNU General Public License.